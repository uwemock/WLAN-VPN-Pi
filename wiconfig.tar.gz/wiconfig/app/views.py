from __future__ import print_function
from app import app
from flask import Flask, render_template, request, redirect, url_for
import socket
import subprocess
import sys
import os
import netifaces
import urllib2
import wifi
from wifi import Cell,Scheme

@app.route('/', methods=['GET', 'POST'])
def config():
    REMOTE_SERVER = "www.google.com"
    # adjust for what's the internet interface

    # check if eth0 is active, otherwise default to wireless. get IP if active.
    try:
        addrs = netifaces.ifaddresses('eth0')
        myip = addrs[netifaces.AF_INET][0]
        myrealip= myip['addr'] + " (connected via ethernet)"
        ethernet = True
    except:
        myrealip="N/A"
        ethernet = False

    # check to see if wlan1 is active, get IP if active
    try:
        addrs = netifaces.ifaddresses('wlan1')
        myip = addrs[netifaces.AF_INET][0]
        myrealip= myip['addr'] + " (connected via wireless)"
        wireless = True
    except:
        myrealip="N/A"
        wireless = False

    # check to see if tun0 (vpn) is active, get IP if active
    try:
        vpn_addrs = netifaces.ifaddresses('tun0')
        myvpnip = vpn_addrs[netifaces.AF_INET][0]
        myvpnrealip= myvpnip['addr']
    except:
        myvpnrealip="N/A"

    try:
        # check to see if we can resolve hostname
        host = socket.gethostbyname(REMOTE_SERVER)
        # connect to the host - can we actually reach it?
        s = socket.create_connection((host, 80), 2)
        connected="Connected"
        response = urllib2.urlopen('http://ipinfo.io/ip')
        publicip = response.read()
    except:
        connected = "NotConnected"
        publicip = "N/A"

    # get available wireless networks
    try:
        networks = Cell.all('wlan1')
    except:
        networks = []
    results = {}

    # get list of configuration files
    config_dir = "/home/pi/vpnconfig"
    config_dir_names = sorted([os.path.join(config_dir,o) for o in os.listdir(config_dir) if os.path.isdir(os.path.join(config_dir,o))])
    config_dir_names.insert(0,config_dir)
    config_file_names = {}
    for dir_name in config_dir_names:
        config_file_names[dir_name] = sorted([f for f in os.listdir(dir_name) if os.path.isfile(os.path.join(dir_name, f))])
    #print(config_dir_names, file=sys.stderr)
    #print(config_file_names, file=sys.stderr)

    # form to get ssid/password and connect
    select_ssid = "N/A"
    select_password = "password"

    # get current SSID from wpa_supplicant service
    wpa_process = subprocess.Popen("wpa_cli status | grep ^ssid", shell=True, stdout=subprocess.PIPE)
    stdout_wpa_process = wpa_process.communicate()[0].split('\n')[0]
    print(stdout_wpa_process[5:], file=sys.stderr)
    current_ssid = stdout_wpa_process[5:]

    if request.method == "POST":
        try:
            # check to see if power off button submitted, if so turn off the Pi
            try:
                poweroff = request.form['poweroff']
            except:
                poweroff = ""
            if poweroff == "true":
                print('powering off...', file=sys.stderr)
                subprocess.call(['poweroff'], shell=True)
                return 'Powering off...'

            # check for reboot Pi
            try:
                reboot = request.form['reboot']
            except:
                reboot = ""
            if reboot == "true":
                print('rebooting...', file=sys.stderr)
                subprocess.call(['reboot'], shell=True)
                return 'Rebooting...'

            # check for (re)starting VPN
            try:
                vpnaction = request.form['vpn']
            except:
                vpnaction = ""
            if vpnaction == "start":
                print('(re)starting VPN', file=sys.stderr)
                subprocess.call(['/home/pi/start-vpn.sh && sleep 10'], shell=True)
                return redirect(url_for('/'))
            if vpnaction == "stop":
                print('stopping VPN', file=sys.stderr)
                subprocess.call(['/home/pi/stop-vpn-common.sh && sleep 10'], shell=True)
                return redirect(url_for('/'))

            # check for switching configuration
            try:
                vpnconfigfile = request.form['vpnconfigfile']
                vpnconfigdir = request.form['vpnconfigdir']
            except:
                vpnconfigfile = ""
                vpnconfigdir = ""
            if vpnconfigfile != "" and vpnconfigdir != "":
                print('switching VPN config to ' + os.path.join(vpnconfigdir, vpnconfigfile), file=sys.stderr)
                subprocess.call(['cp "' + os.path.join(vpnconfigdir, vpnconfigfile) + '" /etc/openvpn/client.conf'], shell=True)
                subprocess.call(['chown root:root /etc/openvpn/client.conf'], shell=True)
                subprocess.call(['chmod 600 /etc/openvpn/client.conf'], shell=True)
                subprocess.call(['service openvpn restart && sleep 10'], shell=True)
                return redirect(url_for('/'))

            # get SSID from form
            try:
                select_ssid = request.form['ssid']
            except:
                select_ssid = ""            
            # get password from form, assume no password if blank
            try:
                select_password = request.form['password']
            except:
                select_password = ""
            # write configuration file for wpa_supplicant
            wpa_config = open("/etc/wpa_supplicant/wpa_supplicant.conf", 'w')
            wpa_config.write("ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev\n")
            wpa_config.write("network={\n")
            wpa_config.write('ssid="' + select_ssid + '"\n')
            
            # if no password, the network is assumed to be unencrypted
            if select_password == "":
                wpa_config.write('key_mgmt=NONE\n}\n\n')
            # password provided so set it in the configuration
            else:
                wpa_config.write('psk="' + select_password + '"\n')
                wpa_config.write('proto=RSN\nkey_mgmt=WPA-PSK\npairwise=CCMP TKIP\ngroup=CCMP TKIP\nauth_alg=OPEN\n}\n\n')
                
            # close configuration file
            wpa_config.close()
            
            # tell wpa_supplicant to reload configuration file
            subprocess.call(['wpa_cli reconfigure'], shell=True)
            
            # kill all previous instances of dhcp client
            subprocess.call(['killall dhclient'], shell=True)
            
            # call dhclient to acquire a public IP via DHCP
            subprocess.call(['dhclient wlan1 -v'], shell=True)
            
            # restart OpenVPN
            subprocess.call(['service openvpn restart && sleep 10'], shell=True)
            
            # return a 302 redirect back to config page after form submitted
            return redirect(url_for('/'))
        except:
            # something bad happened
            print('exception', file=sys.stderr)
    # render template
    return render_template('index.html', connected=connected, publicip=publicip, myrealip=myrealip, myvpnrealip=myvpnrealip, networks=networks, current_ssid=current_ssid, config_dir_names=config_dir_names, config_file_names=config_file_names)
                
